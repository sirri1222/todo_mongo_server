module.exports = {
  mongoURI:
    "mongodb+srv://admin:q1q2q3q4@cluster0.qtjyq1c.mongodb.net/todoData?retryWrites=true&w=majority",
};
